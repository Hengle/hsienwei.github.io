/******************************************************************************
 * Spine Runtimes Software License
 * Version 2.1
 * 
 * Copyright (c) 2013, Esoteric Software
 * All rights reserved.
 * 
 * You are granted a perpetual, non-exclusive, non-sublicensable and
 * non-transferable license to install, execute and perform the Spine Runtimes
 * Software (the "Software") solely for internal use. Without the written
 * permission of Esoteric Software (typically granted by licensing Spine), you
 * may not (a) modify, translate, adapt or otherwise create derivative works,
 * improvements of the Software or develop new applications using the Software
 * or (b) remove, delete, alter or obscure any trademarks or any copyright,
 * trademark, patent or other intellectual property or proprietary rights
 * notices on or in the Software, including any copy thereof. Redistributions
 * in binary or source form must include this license and terms.
 * 
 * THIS SOFTWARE IS PROVIDED BY ESOTERIC SOFTWARE "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL ESOTERIC SOFTARE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package com.esotericsoftware.spine;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;

import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.DataInput;
import com.badlogic.gdx.utils.FloatArray;
import com.badlogic.gdx.utils.IntArray;
import com.badlogic.gdx.utils.SerializationException;
import com.esotericsoftware.spine.Animation.AttachmentTimeline;
import com.esotericsoftware.spine.Animation.ColorTimeline;
import com.esotericsoftware.spine.Animation.CurveTimeline;
import com.esotericsoftware.spine.Animation.DrawOrderTimeline;
import com.esotericsoftware.spine.Animation.EventTimeline;
import com.esotericsoftware.spine.Animation.FfdTimeline;
import com.esotericsoftware.spine.Animation.FlipXTimeline;
import com.esotericsoftware.spine.Animation.FlipYTimeline;
import com.esotericsoftware.spine.Animation.IkConstraintTimeline;
import com.esotericsoftware.spine.Animation.RotateTimeline;
import com.esotericsoftware.spine.Animation.ScaleTimeline;
import com.esotericsoftware.spine.Animation.Timeline;
import com.esotericsoftware.spine.Animation.TranslateTimeline;
import com.esotericsoftware.spine.attachments.AtlasAttachmentLoader;
import com.esotericsoftware.spine.attachments.Attachment;
import com.esotericsoftware.spine.attachments.AttachmentLoader;
import com.esotericsoftware.spine.attachments.AttachmentType;
import com.esotericsoftware.spine.attachments.BoundingBoxAttachment;
import com.esotericsoftware.spine.attachments.MeshAttachment;
import com.esotericsoftware.spine.attachments.RegionAttachment;
import com.esotericsoftware.spine.attachments.SkinnedMeshAttachment;

public class SkeletonBinary {
	static public final int TIMELINE_SCALE = 0;
	static public final int TIMELINE_ROTATE = 1;
	static public final int TIMELINE_TRANSLATE = 2;
	static public final int TIMELINE_ATTACHMENT = 3;
	static public final int TIMELINE_COLOR = 4;
	static public final int TIMELINE_FLIPX = 5;
	static public final int TIMELINE_FLIPY = 6;

	static public final int CURVE_LINEAR = 0;
	static public final int CURVE_STEPPED = 1;
	static public final int CURVE_BEZIER = 2;

	static private final Color tempColor = new Color();

	private final AttachmentLoader attachmentLoader;
	private float scale = 1;
	public JSONObject skJsonData; // crack.

	public SkeletonBinary (TextureAtlas atlas) {
		attachmentLoader = new AtlasAttachmentLoader(atlas);
	}

	public SkeletonBinary (AttachmentLoader attachmentLoader) {
		this.attachmentLoader = attachmentLoader;
	}

	public float getScale () {
		return scale;
	}

	/** Scales the bones, images, and animations as they are loaded. */
	public void setScale (float scale) {
		this.scale = scale;
	}

	public SkeletonData readSkeletonData (FileHandle file) {
		skJsonData = null;// crack.
		if (file == null) throw new IllegalArgumentException("file cannot be null.");

		skJsonData = new JSONObject();// crack.
		float scale = this.scale;

		SkeletonData skeletonData = new SkeletonData();
		skeletonData.name = file.nameWithoutExtension();

		DataInput input = new DataInput(file.read(512));
		try {
			skeletonData.hash = input.readString();
			skJsonData.put("hash", skeletonData.hash);// crack.
			if (skeletonData.hash.isEmpty()) skeletonData.hash = null;
			skeletonData.version = input.readString();
			skJsonData.put("spine", skeletonData.version);// crack.
			if (skeletonData.version.isEmpty()) skeletonData.version = null;
			skeletonData.width = input.readFloat();
			skJsonData.put("width", skeletonData.width);// crack.
			skeletonData.height = input.readFloat();
			skJsonData.put("height", skeletonData.height);// crack.

			boolean nonessential = input.readBoolean();

			if (nonessential) {
				skeletonData.imagesPath = input.readString();
				skJsonData.put("imagesPath", skeletonData.imagesPath);// crack.
				if (skeletonData.imagesPath.isEmpty()) skeletonData.imagesPath = null;
			}

			// Bones.
			JSONArray bonesRoot = new JSONArray();// crack.
			skJsonData.put("bones", bonesRoot);// crack.
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				String name = input.readString();
				BoneData parent = null;
				int parentIndex = input.readInt(true) - 1;
				if (parentIndex != -1) parent = skeletonData.bones.get(parentIndex);
				JSONObject jBone = new JSONObject();// crack.
				//crack start
				if (parentIndex != -1)
				{
					jBone.put("parent", skeletonData.bones.get(parentIndex).getName());
				}
				//crack end
				
				BoneData boneData = new BoneData(name, parent);
				jBone.put("name", name);// crack.
				boneData.x = input.readFloat() * scale;
				jBone.put("x", boneData.x );// crack.
				boneData.y = input.readFloat() * scale;
				jBone.put("y", boneData.y );// crack.
				boneData.scaleX = input.readFloat();
				jBone.put("scaleX", boneData.scaleX);// crack.
				boneData.scaleY = input.readFloat();
				jBone.put("scaleY", boneData.scaleY);// crack.
				boneData.rotation = input.readFloat();
				jBone.put("rotation", boneData.rotation);// crack.
				boneData.length = input.readFloat() * scale;
				jBone.put("length", boneData.length);// crack.
				boneData.flipX = input.readBoolean();
				jBone.put("flipX", boneData.flipX);// crack.
				boneData.flipY = input.readBoolean();
				jBone.put("flipY", boneData.flipY);// crack.
				boneData.inheritScale = input.readBoolean();
				jBone.put("inheritScale", boneData.inheritScale);// crack.
				boneData.inheritRotation = input.readBoolean();
				jBone.put("inheritRotation", boneData.inheritRotation);// crack.
				if (nonessential) Color.rgba8888ToColor(boneData.color, input.readInt());
				jBone.put("color", boneData.color.toString());// crack.
				skeletonData.bones.add(boneData);
				bonesRoot.put(jBone);// crack.
			}

			// IK constraints.
			JSONArray iksRoot = new JSONArray();// crack.
			skJsonData.put("ik", iksRoot);// crack.
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				JSONObject jIK = new JSONObject();// crack.
				IkConstraintData ikConstraintData = new IkConstraintData(input.readString());
				jIK.put("name", ikConstraintData.getName());// crack.
				JSONArray ikBones = new JSONArray();// crack.
				jIK.put("bones", ikBones);// crack.
				for (int ii = 0, nn = input.readInt(true); ii < nn; ii++)
				{//crack.
					int boneIdx = input.readInt(true);//crack
					ikConstraintData.bones.add(skeletonData.bones.get(boneIdx));//crack
					//ikConstraintData.bones.add(skeletonData.bones.get(input.readInt(true)));//origin
					ikBones.put( ikConstraintData.bones.get(boneIdx).getName());// crack.
				}//crack.
				ikConstraintData.target = skeletonData.bones.get(input.readInt(true));
				jIK.put("target", ikConstraintData.target.getName());// crack.
				ikConstraintData.mix = input.readFloat();
				jIK.put("mix", ikConstraintData.mix);// crack.
				ikConstraintData.bendDirection = input.readByte();
				jIK.put("bendPositive", ikConstraintData.bendDirection);// crack.
				skeletonData.ikConstraints.add(ikConstraintData);
				iksRoot.put(jIK);// crack.
			}

			// Slots.
			JSONArray slotRoot = new JSONArray();// crack.
			skJsonData.put("slots", slotRoot);// crack.
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				JSONObject jSlot = new JSONObject();// crack.
				String slotName = input.readString();
				jSlot.put("name", slotName);// crack.
				BoneData boneData = skeletonData.bones.get(input.readInt(true));
				jSlot.put("bone", boneData.getName());// crack.
				SlotData slotData = new SlotData(slotName, boneData);
				Color.rgba8888ToColor(slotData.color, input.readInt());
				jSlot.put("color", slotData.color.toString());// crack.
				slotData.attachmentName = input.readString();
				jSlot.put("attachment", slotData.attachmentName);// crack.
				slotData.additiveBlending = input.readBoolean();
				jSlot.put("additive", slotData.additiveBlending);// crack.
				skeletonData.slots.add(slotData);
				slotRoot.put(jSlot);// crack.
			}

			// Default skin.
			JSONObject skinRoot = new JSONObject();// crack.
			skJsonData.put("skins", skinRoot);// crack.
			Skin defaultSkin = readSkin(input, "default", nonessential, skeletonData);//crack
			if (defaultSkin != null) {
				skeletonData.defaultSkin = defaultSkin;
				skeletonData.skins.add(defaultSkin);
			}

			// Skins.
			for (int i = 0, n = input.readInt(true); i < n; i++)
				skeletonData.skins.add(readSkin(input, input.readString(), nonessential, skeletonData));//crack

			// Events.
			JSONObject eventRoot = new JSONObject();// crack.
			skJsonData.put("events", eventRoot);// crack.
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				JSONObject jEvent = new JSONObject();// crack.
				EventData eventData = new EventData(input.readString());
				eventRoot.put(eventData.getName(), jEvent);// crack.
				eventData.intValue = input.readInt(false);
				jEvent.put("int", eventData.intValue);// crack.
				eventData.floatValue = input.readFloat();
				jEvent.put("float", eventData.floatValue);// crack.
				eventData.stringValue = input.readString();
				jEvent.put("string", eventData.stringValue);// crack.
				skeletonData.events.add(eventData);
			}

			// Animations.
			JSONObject animationRoot = new JSONObject();// crack.
			skJsonData.put("animations", animationRoot);// crack.
			for (int i = 0, n = input.readInt(true); i < n; i++)
				//readAnimation(input.readString(), input, skeletonData);//origin.
				readAnimation(input.readString(), input, skeletonData, animationRoot);//crack.

		} catch (IOException ex) {
			throw new SerializationException("Error reading skeleton file.", ex);
		} finally {
			try {
				input.close();
			} catch (IOException ignored) {
			}
		}

		skeletonData.bones.shrink();
		skeletonData.slots.shrink();
		skeletonData.skins.shrink();
		return skeletonData;
	}

	/** @return May be null. */
	private Skin readSkin (DataInput input, String skinName, boolean nonessential, SkeletonData skData) throws IOException {
		JSONObject skinRoot = skJsonData.getJSONObject("skins");// crack.
		int slotCount = input.readInt(true);
		if (slotCount == 0) return null;
		Skin skin = new Skin(skinName);
		JSONObject jSkin = new JSONObject();// crack.
		skinRoot.put(skinName, jSkin);// crack.
		for (int i = 0; i < slotCount; i++) {
			int slotIndex = input.readInt(true);
			for (int ii = 0, nn = input.readInt(true); ii < nn; ii++) {
				String name = input.readString();
				JSONObject jAttachment = new JSONObject();// crack.
				String slotName = skData.getSlots().get(slotIndex).getName();// crack.
				jSkin.put(slotName, jAttachment);// crack.
				//skin.addAttachment(slotIndex, name, readAttachment(input, skin, name, nonessential));//origin.
				skin.addAttachment(slotIndex, name, readAttachment(input, skin, name, nonessential, jAttachment));// crack.
			}
		}
		return skin;
	}

	//private Attachment readAttachment (DataInput input, Skin skin, String attachmentName, boolean nonessential) throws IOException {//origin.
	private Attachment readAttachment (DataInput input, Skin skin, String attachmentName, boolean nonessential, JSONObject jAttachment) throws IOException {// crack.
		float scale = this.scale;

		String name = input.readString();
		if (name == null) name = attachmentName;
		
		switch (AttachmentType.values()[input.readByte()]) {
		case region: {
			String path = input.readString();
			if (path == null) path = name;
			RegionAttachment region = attachmentLoader.newRegionAttachment(skin, name, path);
			if (region == null) return null;
			JSONObject jSubAttachment = new JSONObject();// crack.
			jAttachment.put(name, jSubAttachment);// crack.
			region.setPath(path);
			jSubAttachment.put("path", path);// crack.
			region.setX(input.readFloat() * scale);
			jSubAttachment.put("x", region.getX());// crack.
			region.setY(input.readFloat() * scale);
			jSubAttachment.put("y", region.getY());// crack.
			region.setScaleX(input.readFloat());
			jSubAttachment.put("scaleX", region.getScaleX());// crack.
			region.setScaleY(input.readFloat());
			jSubAttachment.put("scaleY", region.getScaleY());// crack.
			region.setRotation(input.readFloat());
			jSubAttachment.put("rotation", region.getRotation());// crack.
			region.setWidth(input.readFloat() * scale);
			jSubAttachment.put("width", region.getWidth());// crack.
			region.setHeight(input.readFloat() * scale);
			jSubAttachment.put("height", region.getHeight());// crack.
			Color.rgba8888ToColor(region.getColor(), input.readInt());
			jSubAttachment.put("color", region.getColor().toString());// crack.
			region.updateOffset();
			return region;
		}
		case boundingbox: {
			BoundingBoxAttachment box = attachmentLoader.newBoundingBoxAttachment(skin, name);
			if (box == null) return null;
			JSONObject jSubAttachment = new JSONObject();// crack.
			jAttachment.put(name, jSubAttachment);// crack.
			box.setVertices(readFloatArray(input, scale));
			jSubAttachment.put("type", "boundingbox");// crack.
			jSubAttachment.put("vertices", box.getVertices());// crack.
			return box;
		}
		case mesh: {
			String path = input.readString();
			if (path == null) path = name;
			MeshAttachment mesh = attachmentLoader.newMeshAttachment(skin, name, path);
			if (mesh == null) return null;
			JSONObject jSubAttachment = new JSONObject();// crack.
			jAttachment.put(name, jSubAttachment);// crack.
			mesh.setPath(path);
			float[] uvs = readFloatArray(input, 1);
			short[] triangles = readShortArray(input);
			float[] vertices = readFloatArray(input, scale);
			mesh.setVertices(vertices);
			mesh.setTriangles(triangles);
			mesh.setRegionUVs(uvs);
			mesh.updateUVs();
			Color.rgba8888ToColor(mesh.getColor(), input.readInt());
			mesh.setHullLength(input.readInt(true) * 2);
			if (nonessential) {
				mesh.setEdges(readIntArray(input));
				mesh.setWidth(input.readFloat() * scale);
				mesh.setHeight(input.readFloat() * scale);
			}
			return mesh;
		}
		case skinnedmesh: {
			String path = input.readString();
			if (path == null) path = name;
			SkinnedMeshAttachment mesh = attachmentLoader.newSkinnedMeshAttachment(skin, name, path);
			if (mesh == null) return null;
			JSONObject jSubAttachment = new JSONObject();// crack.
			jAttachment.put(name, jSubAttachment);// crack.
			mesh.setPath(path);
			float[] uvs = readFloatArray(input, 1);
			short[] triangles = readShortArray(input);
			JSONArray uvsAry = new JSONArray();// crack.
			for(int i=0; i< uvs.length; ++i)// crack start.
			{
				uvsAry.put(uvs[i]);
			}// crack end
			JSONArray trianglesAry = new JSONArray();// crack.
			for(int i=0; i< triangles.length; ++i)// crack start.
			{
				trianglesAry.put(triangles[i]);
			}// crack end

			int vertexCount = input.readInt(true);
			FloatArray weights = new FloatArray(uvs.length * 3 * 3);
			IntArray bones = new IntArray(uvs.length * 3);
			JSONArray vertexAry = new JSONArray();// crack.
			for (int i = 0; i < vertexCount; i++) {
				int boneCount = (int)input.readFloat();
				vertexAry.put(boneCount);// crack
				bones.add(boneCount);
				for (int nn = i + boneCount * 4; i < nn; i += 4) {
					/*bones.add((int)input.readFloat());
					weights.add(input.readFloat() * scale);
					weights.add(input.readFloat() * scale);
					weights.add(input.readFloat());*/  //origin
					
					// crack start
					float v1 = input.readFloat();
					float v2 = input.readFloat();
					float v3 = input.readFloat();
					float v4 = input.readFloat();
					bones.add((int)v1);
					weights.add(v2 * scale);
					weights.add(v3 * scale);
					weights.add(v4);
					vertexAry.put(v1);
					vertexAry.put(v2);
					vertexAry.put(v3);
					vertexAry.put(v4);// crack end
				}
			}
			mesh.setBones(bones.toArray());
			mesh.setWeights(weights.toArray());
			mesh.setTriangles(triangles);
			mesh.setRegionUVs(uvs);
			mesh.updateUVs();
			Color.rgba8888ToColor(mesh.getColor(), input.readInt());
			mesh.setHullLength(input.readInt(true) * 2);
			
			jSubAttachment.put("type", "skinnedmesh");// crack
			jSubAttachment.put("uvs", uvsAry);// crack
			jSubAttachment.put("triangles", trianglesAry);// crack
			jSubAttachment.put("vertices", vertexAry);// crack
			jSubAttachment.put("color", mesh.getColor().toString());// crack
			jSubAttachment.put("hull", mesh.getHullLength()/2);// crack
			if (nonessential) {
				mesh.setEdges(readIntArray(input));
				jSubAttachment.put("edges", mesh.getEdges());// crack
				mesh.setWidth(input.readFloat() * scale);
				jSubAttachment.put("width", mesh.getWidth());// crack
				mesh.setHeight(input.readFloat() * scale);
				jSubAttachment.put("height", mesh.getHeight());// crack
			}
			return mesh;
		}
		}
		return null;
	}

	private float[] readFloatArray (DataInput input, float scale) throws IOException {
		int n = input.readInt(true);
		float[] array = new float[n];
		if (scale == 1) {
			for (int i = 0; i < n; i++)
				array[i] = input.readFloat();
		} else {
			for (int i = 0; i < n; i++)
				array[i] = input.readFloat() * scale;
		}
		return array;
	}

	private short[] readShortArray (DataInput input) throws IOException {
		int n = input.readInt(true);
		short[] array = new short[n];
		for (int i = 0; i < n; i++)
			array[i] = input.readShort();
		return array;
	}

	private int[] readIntArray (DataInput input) throws IOException {
		int n = input.readInt(true);
		int[] array = new int[n];
		for (int i = 0; i < n; i++)
			array[i] = input.readInt(true);
		return array;
	}

	//private void readAnimation (String name, DataInput input, SkeletonData skeletonData) {//origin.
	private void readAnimation (String name, DataInput input, SkeletonData skeletonData, JSONObject animationRoot) {//crack.
		Array<Timeline> timelines = new Array();
		float scale = this.scale;
		float duration = 0;
		
		JSONObject jAnimation = new JSONObject();//crack.
		animationRoot.put(name, jAnimation);//crack.

		try {
			// Slot timelines.
			JSONObject jAnimationSlot = new JSONObject();//crack.
			jAnimation.put("slots", jAnimationSlot);//crack.
			
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				int slotIndex = input.readInt(true);
				for (int ii = 0, nn = input.readInt(true); ii < nn; ii++) {
					int timelineType = input.readByte();
					int frameCount = input.readInt(true);
					switch (timelineType) {
					case TIMELINE_COLOR: {
						ColorTimeline timeline = new ColorTimeline(frameCount);
						timeline.slotIndex = slotIndex;
						for (int frameIndex = 0; frameIndex < frameCount; frameIndex++) {
							float time = input.readFloat();
							Color.rgba8888ToColor(tempColor, input.readInt());
							timeline.setFrame(frameIndex, time, tempColor.r, tempColor.g, tempColor.b, tempColor.a);
							if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline, null);
						}
						timelines.add(timeline);
						duration = Math.max(duration, timeline.getFrames()[frameCount * 5 - 5]);
						break;
					}
					case TIMELINE_ATTACHMENT:
						AttachmentTimeline timeline = new AttachmentTimeline(frameCount);
						timeline.slotIndex = slotIndex;
						JSONArray jAnimationSlotAttachment = new JSONArray();//crack.
						String timeLineSlotName = skeletonData.getSlots().get(timeline.slotIndex).getName();//crack.
						jAnimationSlot.put(timeLineSlotName, jAnimationSlotAttachment);//crack.
						//for (int frameIndex = 0; frameIndex < frameCount; frameIndex++)//origin.
						//	timeline.setFrame(frameIndex, input.readFloat(), input.readString());//origin.
						//crack start.
						for (int frameIndex = 0; frameIndex < frameCount; frameIndex++)
						{
							float ftime = input.readFloat();
							String fname = input.readString();
							JSONObject frame = new JSONObject();
							frame.put("time", ftime);
							frame.put("name", fname);
							jAnimationSlotAttachment.put(frame);
							timeline.setFrame(frameIndex, ftime, fname);
						}//crack end.
						timelines.add(timeline);
						duration = Math.max(duration, timeline.getFrames()[frameCount - 1]);
						break;
					}
				}
			}

			// Bone timelines.
			
			JSONObject jAnimationBone = new JSONObject();//crack.
			jAnimation.put("bones", jAnimationBone);//crack.
			
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				int boneIndex = input.readInt(true);
				JSONObject jAnimationBonePart = new JSONObject();//crack.
				String timeLineBoneName = skeletonData.getBones().get(boneIndex).getName();//crack.
				jAnimationBone.put(timeLineBoneName, jAnimationBonePart);//crack.
				
				for (int ii = 0, nn = input.readInt(true); ii < nn; ii++) {
					int timelineType = input.readByte();
					int frameCount = input.readInt(true);
					switch (timelineType) {
					case TIMELINE_ROTATE: {
						RotateTimeline timeline = new RotateTimeline(frameCount);
						timeline.boneIndex = boneIndex;
						JSONArray jAnimationBoneRotate = new JSONArray();//crack.
						jAnimationBonePart.put("rotate", jAnimationBoneRotate);//crack.
						for (int frameIndex = 0; frameIndex < frameCount; frameIndex++) {
							//timeline.setFrame(frameIndex, input.readFloat(), input.readFloat());//origin
							//if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline);//origin
							//crack start
							JSONObject jAnimationBoneRotateFrame = new JSONObject();//crack start
							float ftime =  input.readFloat();
							jAnimationBoneRotateFrame.put("time", ftime);
							float fangle =  input.readFloat();
							jAnimationBoneRotateFrame.put("angle", fangle);
							timeline.setFrame(frameIndex, ftime, fangle);
							if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline, jAnimationBoneRotateFrame);
							jAnimationBoneRotate.put(jAnimationBoneRotateFrame);
							//crack end
						}
						timelines.add(timeline);
						duration = Math.max(duration, timeline.getFrames()[frameCount * 2 - 2]);
						break;
					}
					case TIMELINE_TRANSLATE:
					case TIMELINE_SCALE: {
						TranslateTimeline timeline;
						float timelineScale = 1;
						if (timelineType == TIMELINE_SCALE)
							timeline = new ScaleTimeline(frameCount);
						else {
							timeline = new TranslateTimeline(frameCount);
							timelineScale = scale;
						}
						timeline.boneIndex = boneIndex;
						JSONArray jAnimationBoneTS = new JSONArray();//crack.
						if(timelineType == TIMELINE_TRANSLATE)    jAnimationBonePart.put("translate", jAnimationBoneTS);//crack.
						else    jAnimationBonePart.put("scale", jAnimationBoneTS);//crack.
						for (int frameIndex = 0; frameIndex < frameCount; frameIndex++) {
							//timeline.setFrame(frameIndex, input.readFloat(), input.readFloat() * timelineScale, input.readFloat()//origin
							//	* timelineScale);//origin
							//if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline);//origin
							
							//crack start
							JSONObject jAnimationBoneTSFrame = new JSONObject();
							float ftime = input.readFloat();
							jAnimationBoneTSFrame.put("time", ftime);
							float fx = input.readFloat();
							jAnimationBoneTSFrame.put("x", fx);
							float fy = input.readFloat();
							jAnimationBoneTSFrame.put("y", fy);
							timeline.setFrame(frameIndex, ftime, fx * timelineScale, fy * timelineScale);
							if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline, jAnimationBoneTSFrame);
							jAnimationBoneTS.put(jAnimationBoneTSFrame);
							//crack end
						}
						timelines.add(timeline);
						duration = Math.max(duration, timeline.getFrames()[frameCount * 3 - 3]);
						break;
					}
					case TIMELINE_FLIPX:
					case TIMELINE_FLIPY: {
						FlipXTimeline timeline = timelineType == TIMELINE_FLIPX ? new FlipXTimeline(frameCount) : new FlipYTimeline(
							frameCount);
						timeline.boneIndex = boneIndex;
						for (int frameIndex = 0; frameIndex < frameCount; frameIndex++)
							timeline.setFrame(frameIndex, input.readFloat(), input.readBoolean());
						timelines.add(timeline);
						duration = Math.max(duration, timeline.getFrames()[frameCount * 2 - 2]);
						break;
					}
					}
				}
			}

			// IK timelines.
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				IkConstraintData ikConstraint = skeletonData.ikConstraints.get(input.readInt(true));
				int frameCount = input.readInt(true);
				IkConstraintTimeline timeline = new IkConstraintTimeline(frameCount);
				timeline.ikConstraintIndex = skeletonData.getIkConstraints().indexOf(ikConstraint, true);
				for (int frameIndex = 0; frameIndex < frameCount; frameIndex++) {
					timeline.setFrame(frameIndex, input.readFloat(), input.readFloat(), input.readByte());
					if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline, null);  //crack
				}
				timelines.add(timeline);
				duration = Math.max(duration, timeline.getFrames()[frameCount * 3 - 3]);
			}

			// FFD timelines.
			for (int i = 0, n = input.readInt(true); i < n; i++) {
				Skin skin = skeletonData.skins.get(input.readInt(true));
				for (int ii = 0, nn = input.readInt(true); ii < nn; ii++) {
					int slotIndex = input.readInt(true);
					for (int iii = 0, nnn = input.readInt(true); iii < nnn; iii++) {
						Attachment attachment = skin.getAttachment(slotIndex, input.readString());
						int frameCount = input.readInt(true);
						FfdTimeline timeline = new FfdTimeline(frameCount);
						timeline.slotIndex = slotIndex;
						timeline.attachment = attachment;
						for (int frameIndex = 0; frameIndex < frameCount; frameIndex++) {
							float time = input.readFloat();

							float[] vertices;
							int vertexCount;
							if (attachment instanceof MeshAttachment)
								vertexCount = ((MeshAttachment)attachment).getVertices().length;
							else
								vertexCount = ((SkinnedMeshAttachment)attachment).getWeights().length / 3 * 2;

							int end = input.readInt(true);
							if (end == 0) {
								if (attachment instanceof MeshAttachment)
									vertices = ((MeshAttachment)attachment).getVertices();
								else
									vertices = new float[vertexCount];
							} else {
								vertices = new float[vertexCount];
								int start = input.readInt(true);
								end += start;
								if (scale == 1) {
									for (int v = start; v < end; v++)
										vertices[v] = input.readFloat();
								} else {
									for (int v = start; v < end; v++)
										vertices[v] = input.readFloat() * scale;
								}
								if (attachment instanceof MeshAttachment) {
									float[] meshVertices = ((MeshAttachment)attachment).getVertices();
									for (int v = 0, vn = vertices.length; v < vn; v++)
										vertices[v] += meshVertices[v];
								}
							}

							timeline.setFrame(frameIndex, time, vertices);
							if (frameIndex < frameCount - 1) readCurve(input, frameIndex, timeline, null);//crack
						}
						timelines.add(timeline);
						duration = Math.max(duration, timeline.getFrames()[frameCount - 1]);
					}
				}
			}

			// Draw order timeline.
			int drawOrderCount = input.readInt(true);
			if (drawOrderCount > 0) {
				DrawOrderTimeline timeline = new DrawOrderTimeline(drawOrderCount);
				int slotCount = skeletonData.slots.size;
				for (int i = 0; i < drawOrderCount; i++) {
					int offsetCount = input.readInt(true);
					int[] drawOrder = new int[slotCount];
					for (int ii = slotCount - 1; ii >= 0; ii--)
						drawOrder[ii] = -1;
					int[] unchanged = new int[slotCount - offsetCount];
					int originalIndex = 0, unchangedIndex = 0;
					for (int ii = 0; ii < offsetCount; ii++) {
						int slotIndex = input.readInt(true);
						// Collect unchanged items.
						while (originalIndex != slotIndex)
							unchanged[unchangedIndex++] = originalIndex++;
						// Set changed items.
						drawOrder[originalIndex + input.readInt(true)] = originalIndex++;
					}
					// Collect remaining unchanged items.
					while (originalIndex < slotCount)
						unchanged[unchangedIndex++] = originalIndex++;
					// Fill in unchanged items.
					for (int ii = slotCount - 1; ii >= 0; ii--)
						if (drawOrder[ii] == -1) drawOrder[ii] = unchanged[--unchangedIndex];
					timeline.setFrame(i, input.readFloat(), drawOrder);
				}
				timelines.add(timeline);
				duration = Math.max(duration, timeline.getFrames()[drawOrderCount - 1]);
			}

			// Event timeline.
			int eventCount = input.readInt(true);
			if (eventCount > 0) {
				EventTimeline timeline = new EventTimeline(eventCount);
				for (int i = 0; i < eventCount; i++) {
					float time = input.readFloat();
					EventData eventData = skeletonData.events.get(input.readInt(true));
					Event event = new Event(eventData);
					event.intValue = input.readInt(false);
					event.floatValue = input.readFloat();
					event.stringValue = input.readBoolean() ? input.readString() : eventData.stringValue;
					timeline.setFrame(i, time, event);
				}
				timelines.add(timeline);
				duration = Math.max(duration, timeline.getFrames()[eventCount - 1]);
			}
		} catch (IOException ex) {
			throw new SerializationException("Error reading skeleton file.", ex);
		}

		timelines.shrink();
		skeletonData.animations.add(new Animation(name, timelines, duration));
	}

	//private void readCurve (DataInput input, int frameIndex, CurveTimeline timeline) throws IOException {//origin
	private void readCurve (DataInput input, int frameIndex, CurveTimeline timeline, JSONObject frame) throws IOException {//crack
		switch (input.readByte()) {
		case CURVE_STEPPED:
			timeline.setStepped(frameIndex);
			if(frame != null)    frame.put("curve", "stepped");//crack
			break;
		case CURVE_BEZIER:
			//setCurve(timeline, frameIndex, input.readFloat(), input.readFloat(), input.readFloat(), input.readFloat());//origin
			//crack start
			float c1 = input.readFloat();
			float c2 = input.readFloat();
			float c3 = input.readFloat();
			float c4 = input.readFloat();
			setCurve(timeline, frameIndex, c1, c2, c3, c4);
			JSONArray cAry = new JSONArray();
			cAry.put(c1);
			cAry.put(c2);
			cAry.put(c3);
			cAry.put(c4);
			if(frame != null)    frame.put("curve", cAry);//crack end
			break;
		}
	}

	void setCurve (CurveTimeline timeline, int frameIndex, float cx1, float cy1, float cx2, float cy2) {
		timeline.setCurve(frameIndex, cx1, cy1, cx2, cy2);
	}
}
