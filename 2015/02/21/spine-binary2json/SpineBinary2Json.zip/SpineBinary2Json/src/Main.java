import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import org.json.JSONArray;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.esotericsoftware.spine.SkeletonBinary;
import com.esotericsoftware.spine.SkeletonData;
import com.esotericsoftware.spine.SkeletonJson;


class SpineFileConvertListener implements ApplicationListener
{
	
	private String readFileAsString(String filePath) throws IOException {
		
        StringBuffer fileData = new StringBuffer();
        BufferedReader reader = new BufferedReader(
                new FileReader(filePath));
        char[] buf = new char[1024];
        int numRead=0;
        while((numRead=reader.read(buf)) != -1){
            String readData = String.valueOf(buf, 0, numRead);
            fileData.append(readData);
        }
        reader.close();
        return fileData.toString();
    }
	
	
	void convert2Json(String filePath)
	{
		File fileBinary = new File(filePath);
		String atlasPath =  fileBinary.getAbsolutePath();
		int lastDotdxAtlas = atlasPath.lastIndexOf(".");
		atlasPath = atlasPath.substring(0, lastDotdxAtlas);
		atlasPath+= ".atlas";
		File fileAtlas = new File(atlasPath);
		
		FileHandle  fhBinary = new FileHandle(fileBinary.getAbsolutePath() );
		FileHandle  fhAtlas = new FileHandle(fileAtlas.getAbsolutePath() );
		


		TextureAtlas atlas =new TextureAtlas(fhAtlas);
		SkeletonBinary  skBinary = new SkeletonBinary (atlas);
		
		SkeletonData skData = skBinary.readSkeletonData(fhBinary);

		
		
		
		FileOutputStream fop = null;
		File file;
		String content = skBinary.skJsonData.toString(3);
 
		try {
 
			String path = fileBinary.getAbsolutePath();
			int lastDotdx = path.lastIndexOf(".");
			path = path.substring(0, lastDotdx);
			path+= ".json";
			System.out.println(path);

			file = new File(path);
			fop = new FileOutputStream(file);
 
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
 
			// get the content in bytes
			byte[] contentInBytes = content.getBytes();
 
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
 
			System.out.println("Done");
 
			} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fop != null) {
					fop.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		File fileBinary2 = new File("D:\\workspace_new\\SpineBinary2Json\\crusader.sprite.walk.json");
		File fileAtlas2 = new File("D:\\workspace_new\\SpineBinary2Json\\crusader.sprite.walk.atlas");
		
		FileHandle  fhBinary2 = new FileHandle(fileBinary2.getAbsolutePath() );
		FileHandle  fhAtlas2 = new FileHandle(fileAtlas2.getAbsolutePath() );
		



		TextureAtlas atlas2 =new TextureAtlas(fhAtlas2);
		SkeletonJson  skBinary2 = new SkeletonJson(atlas2);
		SkeletonData skData2 = skBinary2.readSkeletonData(fhBinary2);
	}
	
	@Override
	public void create() {
		
		String listJson = null;
		try {
			listJson = readFileAsString("./convert_list.json");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		if(listJson == null)    return;
 
		JSONArray listObj = new JSONArray(listJson);
		for(int i=0; i< listObj.length(); ++i)
		{
			convert2Json(listObj.getString(i));
		}
		
		
		

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resize(int arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

}


public class Main {

	static {
        System.loadLibrary("gdx64");
    }
	
	public static final void main(String args[])
	{
		new LwjglApplication (new SpineFileConvertListener(), "empty", 10, 10);
	}
}
